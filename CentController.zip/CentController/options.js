const i18n = {
  vi: { 
    titleLang: "Ngôn ngữ", saveLang: "Lưu ngôn ngữ", 
    titleTime: "Cài đặt thời gian (Giây)", labelMin: "Tự động Thu nhỏ", labelLock: "Tự động Khóa", saveTime: "Lưu cài đặt", 
    titleShortcut: "Phím tắt khóa nhanh", 
    shortcutDesc: "Mặc định: <b>Alt + L</b><br>Khóa trình duyệt ngay lập tức bằng phím tắt.<br>Thay đổi tại: <code>chrome://extensions/shortcuts</code>",
    titlePass: "Đổi mật khẩu", labelCurr: "Mật khẩu hiện tại", labelNew: "Mật khẩu mới", labelRep: "Nhập lại mật khẩu", savePass: "Cập nhật mật khẩu", 
    success: "Đã lưu thành công!", errTime: "Ẩn phải nhỏ hơn Khóa!" 
  },
  en: { 
    titleLang: "Language", saveLang: "Save Language", 
    titleTime: "Time Settings (Seconds)", labelMin: "Auto Minimize", labelLock: "Auto Lock", saveTime: "Save Settings", 
    titleShortcut: "Quick Lock Shortcut", 
    shortcutDesc: "Default: <b>Alt + L</b><br>Instantly lock browser with shortcut.<br>Change at: <code>chrome://extensions/shortcuts</code>",
    titlePass: "Change Password", labelCurr: "Current Password", labelNew: "New Password", labelRep: "Repeat Password", savePass: "Update Password", 
    success: "Saved successfully!", errTime: "Minimize must be less than Lock!" 
  }
};

function updateUI(lang) {
  const t = i18n[lang];
  document.getElementById('title-lang').innerText = t.titleLang;
  document.getElementById('save-lang-btn').innerText = t.saveLang;
  document.getElementById('txt-time-title').innerText = t.titleTime;
  document.getElementById('label-min').innerText = t.labelMin;
  document.getElementById('label-lock').innerText = t.labelLock;
  document.getElementById('save-time-btn').innerText = t.saveTime;
  document.getElementById('title-shortcut').innerText = t.titleShortcut;
  document.getElementById('text-shortcut').innerHTML = t.shortcutDesc;
  document.getElementById('title-pass').innerText = t.titlePass;
  document.getElementById('label-curr').innerText = t.labelCurr;
  document.getElementById('label-new').innerText = t.labelNew;
  document.getElementById('label-rep').innerText = t.labelRep;
  document.getElementById('save-btn').innerText = t.savePass;
}

window.onmousemove = () => chrome.runtime.sendMessage({ action: "user_active" });

function updateInputStates() {
    const minE = document.getElementById('enable-min').checked;
    const lockE = document.getElementById('enable-lock').checked;
    document.getElementById('min-time').disabled = !minE;
    document.getElementById('lock-time').disabled = !lockE;
}

document.getElementById('enable-min').addEventListener('change', updateInputStates);
document.getElementById('enable-lock').addEventListener('change', updateInputStates);

chrome.storage.local.get(['userLang', 'minTime', 'lockTime', 'minEnabled', 'lockEnabled'], (res) => {
  const lang = res.userLang || 'vi';
  document.getElementById('lang-select').value = lang;
  document.getElementById('enable-min').checked = res.minEnabled !== false;
  document.getElementById('enable-lock').checked = res.lockEnabled !== false;
  document.getElementById('min-time').value = res.minTime || 30;
  document.getElementById('lock-time').value = res.lockTime || 60;
  updateInputStates();
  updateUI(lang);
});

document.getElementById('save-time-btn').addEventListener('click', () => {
  const minT = parseInt(document.getElementById('min-time').value);
  const lockT = parseInt(document.getElementById('lock-time').value);
  const minE = document.getElementById('enable-min').checked;
  const lockE = document.getElementById('enable-lock').checked;
  chrome.storage.local.get('userLang', (res) => {
    const lang = res.userLang || 'vi';
    if (minE && lockE && minT >= lockT) alert(i18n[lang].errTime);
    else {
      chrome.storage.local.set({ minTime: minT, lockTime: lockT, minEnabled: minE, lockEnabled: lockE }, () => {
        chrome.runtime.sendMessage({ action: "reset_timer" });
        alert(i18n[lang].success);
      });
    }
  });
});

document.getElementById('save-lang-btn').addEventListener('click', () => {
  const lang = document.getElementById('lang-select').value;
  chrome.storage.local.set({ userLang: lang }, () => { updateUI(lang); alert(i18n[lang].success); });
});

document.getElementById('save-btn').addEventListener('click', () => {
  const curr = document.getElementById('curr-pass').value;
  const n1 = document.getElementById('new-pass').value;
  const n2 = document.getElementById('rep-pass').value;
  chrome.storage.local.get(['userPassword'], (res) => {
    if (curr !== (res.userPassword || "532110")) alert("Sai mật khẩu hiện tại!");
    else if (n1 !== n2) alert("Mật khẩu mới không khớp!");
    else chrome.storage.local.set({ userPassword: n1 }, () => alert("Thành công!"));
  });
});