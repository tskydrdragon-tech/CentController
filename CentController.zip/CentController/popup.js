const i18nPopup = {
  vi: { lock: "Khóa ngay", options: "Cài đặt" },
  en: { lock: "Lock now", options: "Options" }
};

// Cập nhật ngôn ngữ dựa trên userLang đã lưu
chrome.storage.local.get('userLang', (res) => {
  const lang = res.userLang || 'vi';
  document.getElementById('lock-now').innerText = i18nPopup[lang].lock;
  document.getElementById('go-options').innerText = i18nPopup[lang].options;
});

document.getElementById('lock-now').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: "manual_lock" });
  window.close();
});

document.getElementById('go-options').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});