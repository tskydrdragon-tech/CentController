function notify() {
  chrome.runtime.sendMessage({ action: "user_active" });
}
window.addEventListener('mousemove', notify, true);
window.addEventListener('keydown', notify, true);
window.addEventListener('click', notify, true);
window.addEventListener('scroll', notify, true);