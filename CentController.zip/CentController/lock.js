let attempts = 0;
let lockStartTime = Date.now();

const i18n = {
  vi: { title: "Mở khóa Trình duyệt", placeholder: "Nhập mật khẩu", btn: "Mở khóa", err: "Mật khẩu không đúng" },
  en: { title: "Unlock Browser", placeholder: "Enter password", btn: "Unlock", err: "Incorrect password" }
};

function updateUI(lang) {
  const t = i18n[lang] || i18n.vi;
  document.getElementById('lock-title').innerText = t.title;
  document.getElementById('password').placeholder = t.placeholder;
  document.getElementById('unlock-btn').innerText = t.btn;
  document.getElementById('error-msg').innerText = t.err;
  document.getElementById('btn-vi').classList.toggle('active', lang === 'vi');
  document.getElementById('btn-en').classList.toggle('active', lang === 'en');
}

// Kiểm tra thời gian rảnh tại màn hình Lock
setInterval(() => {
  const idleTimeInLock = (Date.now() - lockStartTime) / 1000;

  // Sau 3 phút (180s) rảnh tại màn hình lock -> Thu nhỏ
  if (idleTimeInLock >= 180 && idleTimeInLock < 181) {
    chrome.windows.getCurrent((win) => {
      chrome.windows.update(win.id, { state: "minimized" });
    });
  }

  // Sau 5 phút (300s) rảnh tại màn hình lock -> Thoát hẳn
  if (idleTimeInLock >= 300) {
    chrome.windows.getAll({}, (wins) => wins.forEach(w => chrome.windows.remove(w.id)));
  }
}, 1000);

// Reset lại thời gian rảnh nếu người dùng có tương tác (rê chuột, gõ phím) ở màn hình lock
function resetLockTimer() { lockStartTime = Date.now(); }
window.onmousemove = resetLockTimer;
window.onkeydown = resetLockTimer;

window.onload = () => {
  chrome.storage.local.get('userLang', (res) => updateUI(res.userLang || 'vi'));
  document.getElementById('password').focus();
  setTimeout(() => document.getElementById('password').focus(), 200);
};

document.getElementById('btn-vi').addEventListener('click', () => {
  chrome.storage.local.set({ userLang: 'vi' }, () => updateUI('vi'));
});

document.getElementById('btn-en').addEventListener('click', () => {
  chrome.storage.local.set({ userLang: 'en' }, () => updateUI('en'));
});

document.getElementById('toggle-pass').addEventListener('click', () => {
  const input = document.getElementById('password');
  input.type = input.type === 'password' ? 'text' : 'password';
});

document.getElementById('unlock-btn').addEventListener('click', checkPassword);
document.getElementById('password').addEventListener('keypress', (e) => { if (e.key === 'Enter') checkPassword(); });

function checkPassword() {
  const inputField = document.getElementById('password');
  chrome.storage.local.get(['userPassword'], (res) => {
    if (inputField.value === (res.userPassword || "532110")) {
      chrome.runtime.sendMessage({ action: "unlocked_success" });
    } else {
      attempts++;
      document.getElementById('error-msg').style.display = 'block';
      inputField.value = '';
      if (attempts >= 3) chrome.windows.getAll({}, (wins) => wins.forEach(w => chrome.windows.remove(w.id)));
    }
  });
}