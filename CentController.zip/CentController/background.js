let lastActivity = Date.now();
let isLocked = false;
let isInSystemPage = false;

chrome.runtime.onStartup.addListener(lockBrowser);
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['minTime', 'lockTime'], (res) => {
    if (!res.minTime) {
      chrome.storage.local.set({ minTime: 30, lockTime: 60, minEnabled: true, lockEnabled: true });
    }
  });
  lockBrowser();
});

chrome.windows.onCreated.addListener((window) => {
  chrome.storage.local.get(['isLocked'], (res) => {
    if (res.isLocked && window.type === "normal") {
      chrome.windows.remove(window.id);
    }
  });
});

function checkCurrentTab() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const url = tabs[0].url || "";
      if (url.startsWith("chrome://extensions") || url.startsWith("chrome://settings")) {
        isInSystemPage = true;
        lastActivity = Date.now();
      } else {
        isInSystemPage = false;
      }
    }
  });
}

chrome.tabs.onActivated.addListener(checkCurrentTab);
chrome.tabs.onUpdated.addListener(checkCurrentTab);

function lockBrowser() {
  if (isLocked) return;
  isLocked = true;
  chrome.storage.local.set({ isLocked: true });

  const width = 500, height = 450;
  chrome.system.display.getInfo((displays) => {
    const primaryDisplay = displays[0].workArea;
    const left = Math.round(primaryDisplay.left + (primaryDisplay.width - width) / 2);
    const top = Math.round(primaryDisplay.top + (primaryDisplay.height - height) / 2);

    chrome.windows.create({
      url: "lock.html", type: "popup", width: width, height: height,
      left: left, top: top, focused: true
    }, (lockWin) => {
      chrome.windows.getAll({}, (windows) => {
        windows.forEach((win) => { if (win.id !== lockWin.id) chrome.windows.remove(win.id); });
      });
    });
  });
}

chrome.commands.onCommand.addListener((command) => {
  if (command === "lock-shortcut") lockBrowser();
});

chrome.runtime.onMessage.addListener((request, sender) => {
  if (request.action === "user_active" || request.action === "reset_timer") lastActivity = Date.now();
  if (request.action === "unlocked_success") {
    isLocked = false;
    lastActivity = Date.now();
    chrome.storage.local.set({ isLocked: false });
    chrome.windows.create({ state: "maximized", focused: true });
    if (sender.tab && sender.tab.windowId) chrome.windows.remove(sender.tab.windowId);
  }
  return true;
});

setInterval(() => {
  if (isLocked) return;
  chrome.storage.local.get(['minTime', 'lockTime', 'minEnabled', 'lockEnabled'], (res) => {
    let inactiveTime = (Date.now() - lastActivity) / 1000;
    let minL = isInSystemPage ? 180 : (parseInt(res.minTime) || 30);
    let lockL = isInSystemPage ? 300 : (parseInt(res.lockTime) || 60);

    if (res.minEnabled && inactiveTime >= minL && inactiveTime < minL + 1) {
      chrome.windows.getAll({}, (wins) => {
        wins.forEach(w => { if (w.type === "normal" && w.state !== "minimized") chrome.windows.update(w.id, { state: "minimized" }); });
      });
    }
    if (res.lockEnabled && inactiveTime >= lockL) lockBrowser();
  });
}, 1000);